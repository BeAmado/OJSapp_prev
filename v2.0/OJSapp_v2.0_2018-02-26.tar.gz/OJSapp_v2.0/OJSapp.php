<?php

require_once("appFunctions.php");

$result = myMain();

echo "\n\nProgram ended with result $result\n\n";