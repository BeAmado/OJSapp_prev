<?php

/**
FUNCTIONS DEFINED IN THIS SCRIPT
/*
01) isSettings
02) isValidId
03) isFileId


THIS SCRIPT DEFINES THE VARIABLE $tables FOR USE IN THE ENTIRE APP

Developed in 2017 by Bernardo Amado

*/

// #01)
/**
returns true is $type is something like *settings
*/
function isSettings($type) {
	if (strlen($type) > 8) {
		if (substr($type, -8) === "settings") {
			return true;
		}
	}
	return false;
}

// #02)
/**
returns true is $type is something like *_id
*/
function isValidId($type) {
	if (strlen($type) > 3) {
		if (substr($type, -3) === "_id") {
			return true;
		}
	}
	return false;
}


// #03)
/**
returns true is $type is something like *file_id
*/
function isFileId($type) {
	if (strlen($type) >= 7) {
		if (substr($type, -7) === "file_id") {
			return true;
		}
	}
	return false;
}


//the variable tables stores the properties of the OJS database tables that might be used in the app
$tables = [
	"article" => array(),
	"article_comment" => array(),
	"article_file" => array(),
	"article_galley" => array(),
	"article_galley_settings" => array(),
	"article_html_galley_image" => array(),
	"article_settings" => array(),
	"article_supplementary_file" => array(),
	"article_supp_file_settings" => array(),
	"article_search_object" => array(),
	"article_search_object_keyword" => array(),
	"article_search_keyword_list" => array(),
	"article_xml_galley" => array(),
	"edit_assignment" => array(),
	"edit_decision" => array(),
	"review_assignment" => array(),
	"review_round" => array(),
	"review_form" => array(),
	"review_form_settings" => array(),
	"review_form_element" => array(),
	"review_form_element_settings" => array(),
	"review_form_response" => array(),
	"role" => array(),
	"user" => array(), 
	"user_settings" => array(),
	"section" => array(),
	"section_settings" => array()
];


$tables["article"]["attributes"] = ["article_id", "user_id", "journal_id", "section_id", "language", "comments_to_ed", "date_submitted", "last_modified", 
"date_status_modified", "status", "submission_progress", "current_round", "submission_file_id", "revised_file_id", "review_file_id", "editor_file_id", 
"pages", "fast_tracked", "hide_author","comments_status", "locale", "citations"];
$tables["article"]["primary_keys"] = ["article_id"];
$tables["article"]["foreign_keys"] = ["user_id", "journal_id", "section_id"];
$tables["article"]["properties"] = [];
$tables["article"]["properties"]["article_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["article"]["properties"]["user_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["article"]["properties"]["journal_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["article"]["properties"]["section_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["article"]["properties"]["language"] = ["type" => "varchar(10)", "null" => "yes", "key" => "", "default" => "en", "extra" => ""];
$tables["article"]["properties"]["comments_to_ed"] = ["type" => "text", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article"]["properties"]["date_submitted"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article"]["properties"]["last_modified"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article"]["properties"]["date_status_modified"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article"]["properties"]["status"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 1, "extra" => ""];
$tables["article"]["properties"]["submission_progress"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 1, "extra" => ""];
$tables["article"]["properties"]["current_round"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 1, "extra" => ""];
$tables["article"]["properties"]["submission_file_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article"]["properties"]["revised_file_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article"]["properties"]["review_file_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article"]["properties"]["editor_file_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article"]["properties"]["pages"] = ["type" => "varchar(255)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article"]["properties"]["fast_tracked"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["article"]["properties"]["hide_author"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["article"]["properties"]["comments_status"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["article"]["properties"]["locale"] = ["type" => "varchar(5)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article"]["properties"]["citations"] = ["type" => "text", "null" => "yes", "key" => "", "default" => null, "extra" => ""];

$tables["article_settings"]["attributes"] = ["article_id", "locale", "setting_name", "setting_value", "setting_type"];
$tables["article_settings"]["primary_keys"] = ["article_id", "locale", "setting_name"];
$tables["article_settings"]["foreign_keys"] = [];
$tables["article_settings"]["properties"] = [];
$tables["article_settings"]["properties"]["article_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["article_settings"]["properties"]["locale"] = ["type" => "varchar(5)", "null" => "no", "key" => "pri", "default" => "", "extra" => ""];
$tables["article_settings"]["properties"]["setting_name"] = ["type" => "varchar(255)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["article_settings"]["properties"]["setting_value"] = ["type" => "text", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_settings"]["properties"]["setting_type"] = ["type" => "varchar(6)", "null" => "no", "key" => "", "default" => null, "extra" => ""];


$tables["article_comment"]["attributes"] = ["comment_id", "comment_type", "role_id", "article_id", 
"assoc_id", "author_id", "commment_title", "comments", "date_posted", "date_modified", "viewable"];
$tables["article_comment"]["primary_keys"] = ["comment_id"];
$tables["article_comment"]["foreign_keys"] = ["article_id"];
$tables["article_comment"]["properties"] = [];
$tables["article_comment"]["properties"]["comment_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["article_comment"]["properties"]["comment_type"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_comment"]["properties"]["role_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "", "default" => null, "extra" => ""];
$tables["article_comment"]["properties"]["article_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["article_comment"]["properties"]["assoc_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "", "default" => null, "extra" => ""];
$tables["article_comment"]["properties"]["author_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "", "default" => null, "extra" => ""];
$tables["article_comment"]["properties"]["comment_title"] = ["type" => "varchar(255)", "null" => "no", "key" => "", "default" => "Titulo do comentario", "extra" => ""];
$tables["article_comment"]["properties"]["comments"] = ["type" => "text", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_comment"]["properties"]["date_posted"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_comment"]["properties"]["date_modified"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_comment"]["properties"]["viewable"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => null, "extra" => ""];


$tables["article_file"]["attributes"] = ["file_id", "revision", "source_file_id", "source_revision", "article_id", "file_name", "file_type", 
"file_size", "original_file_name","file_stage", "viewable", "date_uploaded", "date_modified", "round", "assoc_id"];
$tables["article_file"]["primary_keys"] = ["file_id", "revision"];
$tables["article_file"]["foreign_keys"] = ["article_id"];
$tables["article_file"]["properties"] = [];
$tables["article_file"]["properties"]["file_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["article_file"]["properties"]["revision"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["article_file"]["properties"]["source_file_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_file"]["properties"]["source_revision"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_file"]["properties"]["article_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["article_file"]["properties"]["file_name"] = ["type" => "varchar(90)", "null" => "no", "key" => "", "default" => null, "extra" => ""];
$tables["article_file"]["properties"]["file_type"] = ["type" => "varchar(255)", "null" => "no", "key" => "", "default" => null, "extra" => ""];
$tables["article_file"]["properties"]["file_size"] = ["type" => "bigint(20)", "null" => "no", "key" => "", "default" => null, "extra" => ""];
$tables["article_file"]["properties"]["original_file_name"] = ["type" => "varchar(127)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_file"]["properties"]["file_stage"] = ["type" => "bigint(20)", "null" => "no", "key" => "", "default" => null, "extra" => ""];
$tables["article_file"]["properties"]["viewable"] = ["type" => "tinyint(4)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_file"]["properties"]["date_uploaded"] = ["type" => "datetime", "null" => "no", "key" => "", "default" => null, "extra" => ""];
$tables["article_file"]["properties"]["date_modified"] = ["type" => "datetime", "null" => "no", "key" => "", "default" => null, "extra" => ""];
$tables["article_file"]["properties"]["round"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => null, "extra" => ""];
$tables["article_file"]["properties"]["assoc_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];


$tables["article_supplementary_file"]["attributes"] = ["supp_id", "file_id", "article_id", "type", "language", "date_created", "show_reviewers", "date_submitted", "seq", "remote_url"];
$tables["article_supplementary_file"]["primary_keys"] = ["supp_id"];
$tables["article_supplementary_file"]["foreign_keys"] = ["file_id", "article_id"];
$tables["article_supplementary_file"]["properties"] = [];
$tables["article_supplementary_file"]["properties"]["supp_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["article_supplementary_file"]["properties"]["file_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["article_supplementary_file"]["properties"]["article_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["article_supplementary_file"]["properties"]["type"] = ["type" => "varchar(255)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_supplementary_file"]["properties"]["language"] = ["type" => "varchar(10)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_supplementary_file"]["properties"]["date_created"] = ["type" => "date", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_supplementary_file"]["properties"]["show_reviewers"] = ["type" => "tinyint(4)", "null" => "yes", "key" => "", "default" => 0, "extra" => ""];
$tables["article_supplementary_file"]["properties"]["date_submitted"] = ["type" => "datetime", "null" => "no", "key" => "", "default" => null, "extra" => ""];
$tables["article_supplementary_file"]["properties"]["seq"] = ["type" => "double", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["article_supplementary_file"]["properties"]["remote_url"] = ["type" => "varchar(255)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];

$tables["article_supp_file_settings"]["attributes"] = ["supp_id", "locale", "setting_name", "setting_value", "setting_type"];
$tables["article_supp_file_settings"]["primary_keys"] = ["supp_id", "locale", "setting_name"];
$tables["article_supp_file_settings"]["foreign_keys"] = [];
$tables["article_supp_file_settings"]["properties"] = [];
$tables["article_supp_file_settings"]["properties"]["supp_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["article_supp_file_settings"]["properties"]["locale"] = ["type" => "varchar(5)", "null" => "no", "key" => "pri", "default" => "", "extra" => ""];
$tables["article_supp_file_settings"]["properties"]["setting_name"] = ["type" => "varchar(255)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["article_supp_file_settings"]["properties"]["setting_value"] = ["type" => "text", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_supp_file_settings"]["properties"]["setting_type"] = ["type" => "varchar(6)", "null" => "no", "key" => "", "default" => null, "extra" => ""];


$tables["article_galley"]["attributes"] = ["galley_id", "locale", "article_id", "file_id", "label", "html_galley", "style_file_id", "seq", "remote_url"];
$tables["article_galley"]["primary_keys"] = ["galley_id"];
$tables["article_galley"]["foreign_keys"] = ["article_id", "file_id", "style_file_id"];
$tables["article_galley"]["properties"] = [];
$tables["article_galley"]["properties"]["galley_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["article_galley"]["properties"]["locale"] = ["type" => "varchar(5)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_galley"]["properties"]["article_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["article_galley"]["properties"]["file_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "", "default" => null, "extra" => ""];
$tables["article_galley"]["properties"]["label"] = ["type" => "varchar(32)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_galley"]["properties"]["html_galley"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["article_galley"]["properties"]["style_file_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_galley"]["properties"]["seq"] = ["type" => "double", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["article_galley"]["properties"]["remote_url"] = ["type" => "varchar(255)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];

$tables["article_galley_settings"]["attributes"] = ["galley_id", "locale", "setting_name", "setting_value", "setting_type"];
$tables["article_galley_settings"]["primary_keys"] = ["galley_id", "locale", "setting_name"];
$tables["article_galley_settings"]["foreign_keys"] = [];
$tables["article_galley_settings"]["properties"] = [];
$tables["article_galley_settings"]["properties"]["galley_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["article_galley_settings"]["properties"]["locale"] = ["type" => "varchar(5)", "null" => "no", "key" => "pri", "default" => "", "extra" => ""];
$tables["article_galley_settings"]["properties"]["setting_name"] = ["type" => "varchar(255)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["article_galley_settings"]["properties"]["setting_value"] = ["type" => "text", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["article_galley_settings"]["properties"]["setting_type"] = ["type" => "varchar(6)", "null" => "no", "key" => "", "default" => "-type-", "extra" => ""];


$tables["article_html_galley_image"]["attributes"] = ["galley_id", "file_id"];
$tables["article_html_galley_image"]["primary_keys"] = ["galley_id", "file_id"];
$tables["article_html_galley_image"]["foreign_keys"] = [];
$tables["article_html_galley_image"]["properties"] = [];
$tables["article_html_galley_image"]["properties"]["galley_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["article_html_galley_image"]["properties"]["file_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];


$tables["article_xml_galley"]["attributes"] = ["xml_galley_id", "galley_id", "article_id", "label", "galley_type", "views"];
$tables["article_xml_galley"]["primary_keys"] = ["xml_galley_id"];
$tables["article_xml_galley"]["foreign_keys"] = ["galley_id", "article_id"];
$tables["article_xml_galley"]["properties"] = [];
$tables["article_xml_galley"]["properties"]["xml_galley_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["article_xml_galley"]["properties"]["galley_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["article_xml_galley"]["properties"]["article_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["article_xml_galley"]["properties"]["label"] = ["type" => "varchar(32)", "null" => "no", "key" => "", "default" => "--label--", "extra" => ""];
$tables["article_xml_galley"]["properties"]["galley_type"] = ["type" => "varchar(255)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["article_xml_galley"]["properties"]["views"] = ["type" => "int(11)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];

	
$tables["article_search_object"]["attributes"] = ["object_id", "article_id", "type", "assoc_id"];
$tables["article_search_object"]["primary_keys"] = ["object_id"];
$tables["article_search_object"]["foreign_keys"] = ["article_id"];
$tables["article_search_object"]["properties"] = [];
$tables["article_search_object"]["properties"]["object_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["article_search_object"]["properties"]["article_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["article_search_object"]["properties"]["type"] = ["type" => "int(11)", "null" => "no", "key" => "", "default" => 1, "extra" => ""];
$tables["article_search_object"]["properties"]["assoc_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];


$tables["article_search_object_keyword"]["attributes"] = ["object_id", "keyword_id", "pos"];
$tables["article_search_object_keyword"]["primary_keys"] = ["object_id", "pos"];
$tables["article_search_object_keyword"]["foreign_keys"] = ["keyword_id"];
$tables["article_search_object_keyword"]["properties"] = [];
$tables["article_search_object_keyword"]["properties"]["object_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["article_search_object_keyword"]["properties"]["keyword_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["article_search_object_keyword"]["properties"]["pos"] = ["type" => "int(11)", "null" => "no", "key" => "pri", "default" => 10, "extra" => ""];


$tables["article_search_keyword_list"]["attributes"] = ["keyword_id", "keyword_text"];
$tables["article_search_keyword_list"]["primary_keys"] = ["keyword_id"];
$tables["article_search_keyword_list"]["foreign_keys"] = [];
$tables["article_search_keyword_list"]["properties"] = [];
$tables["article_search_keyword_list"]["properties"]["keyword_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["article_search_keyword_list"]["properties"]["keyword_text"] = ["type" => "varchar(60)", "null" => "no", "key" => "uni", "default" => null, "extra" => ""];


$tables["author"]["attributes"] = ["author_id", "submission_id", "primary_contact", "seq", "first_name", "middle_name", "last_name", "country", "email", "url", "user_group_id", "suffix"];
$tables["author"]["primary_keys"] = ["author_id"];
$tables["author"]["foreign_keys"] = ["submission_id"];
$tables["author"]["properties"] = [];
$tables["author"]["properties"]["author_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["author"]["properties"]["submission_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["author"]["properties"]["primary_contact"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["author"]["properties"]["seq"] = ["type" => "double", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["author"]["properties"]["first_name"] = ["type" => "varchar(40)", "null" => "no", "key" => "", "default" => "--first_name--", "extra" => ""];
$tables["author"]["properties"]["middle_name"] = ["type" => "varchar(40)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["author"]["properties"]["last_name"] = ["type" => "varchar(90)", "null" => "no", "key" => "", "default" => "--last_name--", "extra" => ""];
$tables["author"]["properties"]["country"] = ["type" => "varchar(90)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["author"]["properties"]["email"] = ["type" => "varchar(90)", "null" => "no", "key" => "", "default" => "--email--", "extra" => ""];
$tables["author"]["properties"]["url"] = ["type" => "varchar(255)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["author"]["properties"]["user_group_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["author"]["properties"]["suffix"] = ["type" => "varchar(40)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];

$tables["author_settings"]["attributes"] = ["author_id", "locale", "setting_name", "setting_value", "setting_type"];
$tables["author_settings"]["primary_keys"] = ["author_id", "locale", "setting_name"];
$tables["author_settings"]["foreign_keys"] = [];
$tables["author_settings"]["properties"] = [];
$tables["author_settings"]["properties"]["author_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["author_settings"]["properties"]["locale"] = ["type" => "varchar(5)", "null" => "no", "key" => "pri", "default" => "", "extra" => ""];
$tables["author_settings"]["properties"]["setting_name"] = ["type" => "varchar(255)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["author_settings"]["properties"]["setting_value"] = ["type" => "text", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["author_settings"]["properties"]["setting_type"] = ["type" => "varchar(6)", "null" => "no", "key" => "", "default" => null, "extra" => ""];


$tables["edit_assignment"]["attributes"] = ["edit_id", "article_id", "editor_id", "can_edit", "can_review", "date_assigned", "date_notified", "date_underway"];
$tables["edit_assignment"]["primary_keys"] = ["edit_id"];
$tables["edit_assignment"]["foreign_keys"] = ["article_id", "editor_id"];
$tables["edit_assignment"]["properties"] = [];
$tables["edit_assignment"]["properties"]["edit_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["edit_assignment"]["properties"]["article_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["edit_assignment"]["properties"]["editor_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["edit_assignment"]["properties"]["can_edit"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 1, "extra" => ""];
$tables["edit_assignment"]["properties"]["can_review"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 1, "extra" => ""];
$tables["edit_assignment"]["properties"]["date_assigned"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["edit_assignment"]["properties"]["date_notified"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["edit_assignment"]["properties"]["date_underway"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];


$tables["edit_decision"]["attributes"] = ["edit_decision_id", "article_id", "round", "editor_id", "decision", "date_decided"];
$tables["edit_decision"]["primary_keys"] = ["edit_decision_id"];
$tables["edit_decision"]["foreign_keys"] = ["article_id", "editor_id"];
$tables["edit_decision"]["properties"] = [];
$tables["edit_decision"]["properties"]["edit_decision_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["edit_decision"]["properties"]["article_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["edit_decision"]["properties"]["editor_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["edit_decision"]["properties"]["round"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 1, "extra" => ""];
$tables["edit_decision"]["properties"]["decision"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 1, "extra" => ""];
$tables["edit_decision"]["properties"]["date_decided"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];


$tables["review_assignment"]["attributes"] = ["review_id", "submission_id", "reviewer_id", "competing_interests", "recommendation", "date_assigned", "date_notified", "date_confirmed",
"date_completed", "date_acknowledged", "date_due", "last_modified", "reminder_was_automatic", "declined", "replaced", "cancelled", "reviewer_file_id", "date_rated", "date_reminded",
"quality", "round", "review_form_id", "regret_message", "date_response_due", "review_method", "step", "review_round_id", "stage_id", "unconsidered"];
$tables["review_assignment"]["primary_keys"] = ["review_id"];
$tables["review_assignment"]["foreign_keys"] = ["submission_id", "reviewer_id", "review_form_id", "reviewer_file_id"];
$tables["review_assignment"]["properties"] = [];
$tables["review_assignment"]["properties"]["review_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["review_assignment"]["properties"]["submission_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["reviewer_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["competing_interests"] = ["type" => "text", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["recommendation"] = ["type" => "tinyint(4)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["date_assigned"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["date_notified"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["date_confirmed"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["date_completed"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["date_acknowledged"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["date_due"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["last_modified"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["reminder_was_automatic"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["review_assignment"]["properties"]["declined"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["review_assignment"]["properties"]["replaced"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["review_assignment"]["properties"]["cancelled"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["review_assignment"]["properties"]["reviewer_file_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["date_rated"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["date_reminded"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["quality"] = ["type" => "tinyint(4)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["round"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 1, "extra" => ""];
$tables["review_assignment"]["properties"]["review_form_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "mul", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["regret_message"] = ["type" => "text", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["date_response_due"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["review_method"] = ["type" => "tinyint(20)", "null" => "no", "key" => "", "default" => 1, "extra" => ""];
$tables["review_assignment"]["properties"]["step"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 1, "extra" => ""];
$tables["review_assignment"]["properties"]["review_round_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_assignment"]["properties"]["stage_id"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 1, "extra" => ""];
$tables["review_assignment"]["properties"]["unconsidered"] = ["type" => "tinyint(4)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];


$tables["review_round"]["attributes"] = ["submission_id", "round", "review_revision", "status", "review_round_id", "stage_id"];
$tables["review_round"]["primary_keys"] = ["review_round_id"];
$tables["review_round"]["foreign_keys"] = ["submission_id"];
$tables["review_round"]["properties"] = [];
$tables["review_round"]["properties"]["review_round_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["review_round"]["properties"]["submission_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["review_round"]["properties"]["round"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 1, "extra" => ""];
$tables["review_round"]["properties"]["review_revision"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_round"]["properties"]["status"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_round"]["properties"]["stage_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];


$tables["review_form"]["attributes"] = ["review_form_id", "assoc_id", "seq", "is_active", "assoc_type"];
$tables["review_form"]["primary_keys"] = ["review_form_id"];
$tables["review_form"]["foreign_keys"] = [];
$tables["review_form"]["properties"] = [];
$tables["review_form"]["properties"]["review_form_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["review_form"]["properties"]["assoc_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_form"]["properties"]["seq"] = ["type" => "double", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_form"]["properties"]["is_active"] = ["type" => "tinyint(4)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_form"]["properties"]["assoc_type"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_form"]["properties"]["stage_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];

$tables["review_form_settings"]["attributes"] = ["review_form_id", "locale", "setting_name", "setting_value", "setting_type"];
$tables["review_form_settings"]["primary_keys"] = ["review_form_id", "locale", "setting_name"];
$tables["review_form_settings"]["foreign_keys"] = [];
$tables["review_form_settings"]["properties"] = [];
$tables["review_form_settings"]["properties"]["review_form_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["review_form_settings"]["properties"]["locale"] = ["type" => "varchar(5)", "null" => "no", "key" => "pri", "default" => "", "extra" => ""];
$tables["review_form_settings"]["properties"]["setting_name"] = ["type" => "varchar(255)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["review_form_settings"]["properties"]["setting_value"] = ["type" => "text", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_form_settings"]["properties"]["setting_type"] = ["type" => "varchar(6)", "null" => "no", "key" => "", "default" => null, "extra" => ""];


$tables["review_form_element"]["attributes"] = ["review_form_element_id", "review_form_id", "seq", "element_type", "required", "included"];
$tables["review_form_element"]["primary_keys"] = ["review_form_element_id"];
$tables["review_form_element"]["foreign_keys"] = ["review_form_id"];
$tables["review_form_element"]["properties"] = [];
$tables["review_form_element"]["properties"]["review_form_element_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["review_form_element"]["properties"]["review_form_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["review_form_element"]["properties"]["seq"] = ["type" => "double", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_form_element"]["properties"]["element_type"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_form_element"]["properties"]["required"] = ["type" => "tinyint(4)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_form_element"]["properties"]["included"] = ["type" => "tinyint(4)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];

$tables["review_form_element_settings"]["attributes"] = ["review_form_element_id", "locale", "setting_name", "setting_value", "setting_type"];
$tables["review_form_element_settings"]["primary_keys"] = ["review_form_element_id", "locale", "setting_name"];
$tables["review_form_element_settings"]["foreign_keys"] = [];
$tables["review_form_element_settings"]["properties"] = [];
$tables["review_form_element_settings"]["properties"]["review_form_element_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["review_form_element_settings"]["properties"]["locale"] = ["type" => "varchar(5)", "null" => "no", "key" => "pri", "default" => "", "extra" => ""];
$tables["review_form_element_settings"]["properties"]["setting_name"] = ["type" => "varchar(255)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["review_form_element_settings"]["properties"]["setting_value"] = ["type" => "text", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_form_element_settings"]["properties"]["setting_type"] = ["type" => "varchar(6)", "null" => "no", "key" => "", "default" => null, "extra" => ""];


$tables["review_form_response"]["attributes"] = ["review_form_element_id", "review_id", "response_type", "response_value"];
$tables["review_form_response"]["primary_keys"] = [];
$tables["review_form_response"]["foreign_keys"] = ["review_form_element_id", "review_id"];
$tables["review_form_response"]["properties"] = [];
$tables["review_form_response"]["properties"]["review_form_element_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => "auto_increment"];
$tables["review_form_response"]["properties"]["review_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "", "default" => null, "extra" => ""];
$tables["review_form_response"]["properties"]["response_type"] = ["type" => "varchar(6)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["review_form_response"]["properties"]["response_value"] = ["type" => "text", "null" => "yes", "key" => "", "default" => null, "extra" => ""];


$tables["role"]["attributes"] = ["journal_id", "user_id", "role_id"];
$tables["role"]["primary_keys"] = ["journal_id", "user_id", "role_id"];
$tables["role"]["foreign_keys"] = ["journal_id", "user_id"];
$tables["role"]["properties"] = [];
$tables["role"]["properties"]["article_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["role"]["properties"]["user_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["role"]["properties"]["role_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => 65536, "extra" => ""];

	
$tables["user"]["attributes"] = ["user_id", "username", "password", "salutation", "first_name", "middle_name", "last_name", "gender", "initials", "email", "url", "phone", "fax", "mailing_address",
"country", "locales", "date_last_email", "date_registered", "date_validated", "date_last_login", "must_change_password", "auth_id", "disabled", "disabled_reason", "auth_str", 
"suffix", "billing_address", "inline_help"];
$tables["user"]["primary_keys"] = ["user_id"];
$tables["user"]["foreign_keys"] = [];
$tables["user"]["properties"] = [];
$tables["user"]["properties"]["user_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["user"]["properties"]["username"] = ["type" => "varchar(32)", "null" => "no", "key" => "uni", "default" => null, "extra" => ""];
$tables["user"]["properties"]["password"] = ["type" => "varchar(255)", "null" => "no", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["salutation"] = ["type" => "varchar(40)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["first_name"] = ["type" => "varchar(40)", "null" => "no", "key" => "", "default" => "", "extra" => ""];
$tables["user"]["properties"]["middle_name"] = ["type" => "varchar(40)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["last_name"] = ["type" => "varchar(90)", "null" => "no", "key" => "", "default" => "", "extra" => ""];
$tables["user"]["properties"]["gender"] = ["type" => "varchar(1)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["initials"] = ["type" => "varchar(5)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["email"] = ["type" => "varchar(90)", "null" => "no", "key" => "uni", "default" => null, "extra" => ""];
$tables["user"]["properties"]["url"] = ["type" => "varchar(255)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["phone"] = ["type" => "varchar(24)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["fax"] = ["type" => "varchar(24)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["mailing_address"] = ["type" => "varchar(255)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["country"] = ["type" => "varchar(90)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["locales"] = ["type" => "varchar(255)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["date_last_email"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["date_registered"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["date_validated"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["date_last_login"] = ["type" => "datetime", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["must_change_password"] = ["type" => "tinyint(4)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["auth_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["disabled"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["user"]["properties"]["disabled_reason"] = ["type" => "text", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["auth_str"] = ["type" => "varchar(255)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["suffix"] = ["type" => "varchar(40)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["billing_address"] = ["type" => "varchar(255)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user"]["properties"]["inline_help"] = ["type" => "tinyint(4)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];

$tables["user_settings"]["attributes"] = ["user_id", "locale", "setting_name", "setting_value", "setting_type", "assoc_id", "assoc_type"];
$tables["user_settings"]["primary_keys"] = [];
$tables["user_settings"]["foreign_keys"] = ["user_id"];
$tables["user_settings"]["properties"] = [];
$tables["user_settings"]["properties"]["user_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["user_settings"]["properties"]["locale"] = ["type" => "varchar(5)", "null" => "no", "key" => "", "default" => "", "extra" => ""];
$tables["user_settings"]["properties"]["setting_name"] = ["type" => "varchar(255)", "null" => "no", "key" => "", "default" => null, "extra" => ""];
$tables["user_settings"]["properties"]["setting_value"] = ["type" => "text", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["user_settings"]["properties"]["setting_type"] = ["type" => "varchar(6)", "null" => "no", "key" => "", "default" => null, "extra" => ""];
$tables["user_settings"]["properties"]["assoc_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => 0, "extra" => ""];
$tables["user_settings"]["properties"]["assoc_type"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => 0, "extra" => ""];


$tables["section"]["attributes"] = ["section_id", "journal_id", "review_form_id", "seq", "editor_restricted", "meta_indexed", "meta_reviewed", "abstracts_not_required",
"hide_title", "hide_author", "hide_about", "disable_comments", "abstract_word_count"];
$tables["section"]["primary_keys"] = ["section_id"];
$tables["section"]["foreign_keys"] = ["journal_id", "review_form_id"];
$tables["section"]["properties"] = [];
$tables["section"]["properties"]["section_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => "auto_increment"];
$tables["section"]["properties"]["journal_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "mul", "default" => null, "extra" => ""];
$tables["section"]["properties"]["review_form_id"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["section"]["properties"]["seq"] = ["type" => "double", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["section"]["properties"]["editor_restricted"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["section"]["properties"]["meta_indexed"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["section"]["properties"]["meta_reviewed"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 1, "extra" => ""];
$tables["section"]["properties"]["abstracts_not_required"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["section"]["properties"]["hide_title"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["section"]["properties"]["hide_author"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["section"]["properties"]["hide_about"] = ["type" => "tinyint(4)", "null" => "yes", "key" => "", "default" => 0, "extra" => ""];
$tables["section"]["properties"]["disable_comments"] = ["type" => "tinyint(4)", "null" => "no", "key" => "", "default" => 0, "extra" => ""];
$tables["section"]["properties"]["abstract_word_count"] = ["type" => "bigint(20)", "null" => "yes", "key" => "", "default" => null, "extra" => ""];

$tables["section_settings"]["attributes"] = ["section_id", "locale", "setting_name", "setting_value", "setting_type"];
$tables["section_settings"]["primary_keys"] = ["section_id", "locale", "setting_name"];
$tables["section_settings"]["foreign_keys"] = [];
$tables["section_settings"]["properties"] = [];
$tables["section_settings"]["properties"]["section_id"] = ["type" => "bigint(20)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["section_settings"]["properties"]["locale"] = ["type" => "varchar(5)", "null" => "no", "key" => "pri", "default" => "", "extra" => ""];
$tables["section_settings"]["properties"]["setting_name"] = ["type" => "varchar(255)", "null" => "no", "key" => "pri", "default" => null, "extra" => ""];
$tables["section_settings"]["properties"]["setting_value"] = ["type" => "text", "null" => "yes", "key" => "", "default" => null, "extra" => ""];
$tables["section_settings"]["properties"]["setting_type"] = ["type" => "varchar(6)", "null" => "no", "key" => "", "default" => null, "extra" => ""];

$idFields = [];
foreach ($tables as $type => $arr) {
	foreach ($arr["primary_keys"] as $pk) {
		if (!in_array($pk, $idFields) && isValidId($pk) && !isSettings($type)) {
			array_push($idFields, $pk);
		}
	}
	foreach ($arr["foreign_keys"] as $fk) {
		if (!in_array($fk, $idFields) && isValidId($fk) && !isSettings($type)) {
			array_push($idFields, $fk);
		}
	}
	foreach ($arr["attributes"] as $attr) {
		if (!in_array($attr, $idFields) && isFileId($attr) && !isSettings($type)) {
			array_push($idFields, $attr);
		}
	}
}


$updateFields = $idFields;

//array_push($updateFields, "comment_author_id");
array_push($updateFields, "file_name");
array_push($updateFields, "original_file_name");



