<?php

//////////////  IN THE OJSapp to correct the charset to UTF-8  ///////////////////////////////
/**
ascii codes:
10 -> line jump (\n)
32 -> empty space
38 -> & (ampersand)
58 -> : (colon)
59 -> ; (semicolon)

A:
195,128 -> À (&Agrave; -> 38 65 103 114 97 118 101 59)
195,129 -> Á (&Aacute; -> 38 65 97 99 117 116 101 59)
195,130 -> Â (&Acirc; -> 38 65 99 105 114 99 59)
195,131 -> Ã (&Atilde; -> 38,65,116,105,108,100,101,59)

195,160 -> à (&agrave; -> 38 97 103 114 97 118 101 59)
195,161 -> á (&aacute; -> 38 97 97 99 117 116 101 59)
195,162 -> â (&acirc; -> 38 97 99 105 114 99 59)
195,163 -> ã (&atilde; -> 38,97,116,105,108,100,101,59)


E:
195,136 -> È (&Egrave; -> 38,69,103,114,97,118,101,59)
195,137 -> É (&Eacute; -> 38,69,97,99,117,116,101,59)
195,138 -> Ê (&Ecirc; -> 38,69,99,105,114,99,59)

195,168 -> è (&egrave; -> 38,101,103,114,97,118,101,59)
195,169 -> é (&eacute; -> 38,101,97,99,117,116,101,59)
195,170 -> ê (&ecirc; -> 38,101,99,105,114,99,59)


I:

195,140 -> Ì (&Igrave; -> 38,73,103,114,97,118,101,59)
195,141 -> Í (&Iacute; -> 38,73,97,99,117,116,101,59)
195,142 -> Î (&Icirc; -> 38,73,99,105,114,99,59)
195,143 -> Ï (&Iuml; -> 38,73,117,109,108,59)

195,172 -> ì (&igrave; -> 38,105,103,114,97,118,101,59)
195,173 -> í (&iacute; -> 38,105,97,99,117,116,101,59)
195,174 -> î (&icirc; -> 38,105,99,105,114,99,59)
195,175 -> ï (&iuml; -> 38,105,117,109,108,59)

O:
195,146 -> Ò (&Ograve; -> 38 79 103 114 97 118 101 59)
195,147 -> Ó (&Oacute; -> 38 79 97 99 117 116 101 59)
195,148 -> Ô (&Ocirc; -> 38 79 99 105 114 99 59)
195,149 -> Õ (&Otilde; -> 38,79,116,105,108,100,101,59)

195,178 -> ò (&ograve; -> 38 111 103 114 97 118 101 59)
195,179 -> ó (&oacute; -> 38 111 97 99 117 116 101 59)
195,180 -> ô (&ocirc; -> 38 111 99 105 114 99 59)
195,181 -> õ (&otilde; -> 38,111,116,105,108,100,101,59)

U:
195,153 -> Ù (&Ugrave; -> 38 85 103 114 97 118 101 59)
195,154 -> Ú (&Uacute; -> 38 85 97 99 117 116 101 59)
195,155 -> Û (&Ucirc; -> 38 85 99 105 114 99 59)
195,156 -> Ü (&Uuml; -> 38,85,117,109,108,59)

195,185 -> ù (&ugrave; -> 38 117 103 114 97 118 101 59)
195,186 -> ú (&uacute; -> 38 117 97 99 117 116 101 59)
195,187 -> û (&ucirc; -> 38 117 99 105 114 99 59)
195,188 -> ü (&uuml; -> 38,117,117,109,108,59)


195,167 -> ç (&ccedil; -> 38,99,99,101,100,105,108,59)
195,135 -> Ç (&Ccedil; -> 38,67,99,101,100,105,108,59) 

226,128,147  -> large dash. Should be translated into - which is code 45



$codes = array(
	////////////////// A ///////////////////////////////
	'Agrave' => array('raw' => array(195,128), 'entity' => str2codes('&Agrave;')),
	'Aacute' => array('raw' => array(195,129), 'entity' => str2codes('&Aacute;')),
	'Acirc' => array('raw' => array(195,130), 'entity' => str2codes('&Acirc;')),
	'Atilde' => array('raw' => array(195,131), 'entity' => str2codes('&Atilde;')),
	
	'agrave' => array('raw' => array(195,160), 'entity' => str2codes('&agrave;')),
	'aacute' => array('raw' => array(195,161), 'entity' => str2codes('&acute;')),
	'acirc' => array('raw' => array(195,162), 'entity' => str2codes('&acirc;')),
	'atilde' => array('raw' => array(195,163), 'entity' => str2codes('&atilde;')),
	
	//////////////////// E ////////////////////////////
	'Egrave' => array('raw' => array(195,136), 'entity' => str2codes('&Egrave;')),
	'Eacute' => array('raw' => array(195,137), 'entity' => str2codes('&Eacute;')),
	'Ecirc' => array('raw' => array(195,138), 'entity' => str2codes('&Ecirc;')),
	
	'egrave' => array('raw' => array(195,168), 'entity' => str2codes('&egrave;')),
	'eacute' => array('raw' => array(195,169), 'entity' => str2codes('&ecute;')),
	'ecirc' => array('raw' => array(195,170), 'entity' => str2codes('&ecirc;')),
	
	////////////////// I ///////////////////////////////////
	'Igrave' => array('raw' => array(195,140), 'entity' => str2codes('&Igrave;')),
	'Iacute' => array('raw' => array(195,141), 'entity' => str2codes('&Iacute;')),
	'Icirc' => array('raw' => array(195,142), 'entity' => str2codes('&Icirc;')),
	'Iuml' => array('raw' => array(195,143), 'entity' => str2codes('&Iuml;')),
	
	'igrave' => array('raw' => array(195,172), 'entity' => str2codes('&igrave;')),
	'iacute' => array('raw' => array(195,173), 'entity' => str2codes('&icute;')),
	'icirc' => array('raw' => array(195,174), 'entity' => str2codes('&icirc;')),
	'iuml' => array('raw' => array(195,175), 'entity' => str2codes('&iuml;')),
	
	///////////////// O //////////////////////////////////////
	'Ograve' => array('raw' => array(195,146), 'entity' => str2codes('&Ograve;')),
	'Oacute' => array('raw' => array(195,147), 'entity' => str2codes('&Oacute;')),
	'Ocirc' => array('raw' => array(195,148), 'entity' => str2codes('&Ocirc;')),
	'Otilde' => array('raw' => array(195,149), 'entity' => str2codes('&Otilde;')),
	
	'ograve' => array('raw' => array(195,178), 'entity' => str2codes('&ograve;')),
	'oacute' => array('raw' => array(195,179), 'entity' => str2codes('&ocute;')),
	'ocirc' => array('raw' => array(195,180), 'entity' => str2codes('&ocirc;')),
	'otilde' => array('raw' => array(195,181), 'entity' => str2codes('&otilde;')),
	
	///////////////// U ////////////////////////////////////////
	'Ugrave' => array('raw' => array(195,153), 'entity' => str2codes('&Ugrave;')),
	'Uacute' => array('raw' => array(195,154), 'entity' => str2codes('&Uacute;')),
	'Ucirc' => array('raw' => array(195,155), 'entity' => str2codes('&Ucirc;')),
	'Uuml' => array('raw' => array(195,156), 'entity' => str2codes('&Uuml;')),
	
	'ugrave' => array('raw' => array(195,185), 'entity' => str2codes('&ugrave;')),
	'uacute' => array('raw' => array(195,186), 'entity' => str2codes('&ucute;')),
	'ucirc' => array('raw' => array(195,187), 'entity' => str2codes('&ucirc;')),
	'uuml' => array('raw' => array(195,188), 'entity' => str2codes('&uuml;')),
	
	//////////// Ç ///////////////////////////////////////////////
	'Ccedil' => array('raw' => array(195,135), 'entity' => str2codes('&Ccedil;')),
	'ccedil' => array('raw' => array(195,167), 'entity' => str2codes('&ccedil;')),
);

//////////////////////////////////////////////////////////////////////////////////////////////

*/

/**
fetch all the data from a database table and return as an array
*/
function fetchTable(&$conn, $tableName) {
	$name = filter_var($tableName, FILTER_SANITIZE_STRING);
	try {
		$query = "SELECT * FROM $tableName";
		
		$stmt = $conn->prepare($query);
		echo "\nFetching $tableName ...... ";
		if ($stmt->execute()) {
			$records = $stmt->fetchAll(PDO::FETCH_ASSOC);
			echo "Ok\n";
			return $records;
		}
		else {
			echo "Error\n";
			echo "Did not execute the statement: $query\nThe error was " . $stmt->errorInfo() . "\n";
			return false;
		}
	}
	catch (PDOException $e) {
		echo "\nThe function fetchTable raised an Exception\n";
		echo "The arguments were: " .
		"\nconn: " . print_r($conn, true) .
		"\ntableName: $tableName which sanitized to $name\n\n";
		echo "The exception was: " . $e->getMessage();
	}
}

/**
Fetch the data form all the tables in collations
*/
function fetchData(&$conn, $collations, $isAssociative = false) {
	
	$tables = array();
	
	if ($isAssociative) {
		foreach ($collations as $tableName => $collation) {
			if (strpos($collation, 'latin') !== false) {
				//the item collation is of type ISO-8859-1 or very similar
				$table = fetchTable($conn, $tableName);
				
				if (is_array($table)) {
					if (count($table) > 0) {
						$tables[$tableName] = $table;
					}
				}//end of the table is an array 
				
			}//end of the if collation is latin
		}//end of the foreach
	}//end of the if isAssociative
	else {
		foreach ($collations as $tableName) {
			$table = fetchTable($conn, $tableName);
			
			if (is_array($table)) {
				if (count($table) > 0) {
					$tables[$tableName] = $table;
				}
				else {
					echo "\nThe table $tableName is empty\n";
				}
			} 
			else {
				echo "\nThe table $tableName is not an array (probably occurred some errors)\n";
			}
			
		}//end of the foreach
	}//end of the else
	
	return $tables;
	
}


/**

*/
function translateData(&$tables) {
	
	require_once('helperFunctions.php'); // the function translateArray2utf8 is in this file
	
	$map = array();
	foreach ($tables as $name => $data) {
		echo "\nTranslating the table $name...";
		$newData = $data;
		translateArray2utf8($newData);
		$map[$name] = array('fields' => array_keys($data[0]), 'original' => $data, 'translated' => $newData);
		echo "Ok\n";
	}
	
	return $map;
}

/**
Returns the time like **h **m **s given the parameter time in seconds
*/
function timeString($time) {
	$hours = floor($time / 3600);
	$time %= 3600;
	
	$minutes = floor($time / 60);
	$seconds = $time % 60;
	
	return $hours . 'h ' . $minutes . 'min ' . $seconds . 's';
}


function updateTable(&$conn, $tableName, &$mappedTable) {
	$attributes = $mappedTable['fields'];
	
	$query = "UPDATE $tableName SET ";
	
	///////// fill the query ///////////////////////////
	$numAttributes = count($attributes); 
	for ($i = 0; $i < $numAttributes - 1; $i++) {
		$attr = $attributes[$i];
		$query .= "$attr = :value_$attr, ";
	}
	
	// the last attribute in the query
	$attr = $attributes[$numAttributes - 1];
	$query .= "$attr = :value_$attr";
	
	///// the conditions /////////////
	$query .= " WHERE ";
	
	for ($i = 0; $i < $numAttributes - 1; $i++) {
		$attr = $attributes[$i];
		$query .= "$attr = :cond_$attr AND ";
	}
	
	// the last attribute in the query
	$attr = $attributes[$numAttributes - 1];
	$query .= "$attr = :cond_$attr";
	/////////////////  query filled  ////////////////////
	
	$stmt = $conn->prepare($query);
	
	$numRecords = count($mappedTable['translated']);
	
	echo "\n---------- UPDATING TABLE $tableName -----------\n";
	echo "\n$numRecords sets will be updated.\n";
	$updatedSets = 0;
	
	$beginTime = time();
	
	for ($i = 0; $i < $numRecords; $i++) {
		if (($updatedSets % 5000 === 0) && ($updatedSets > 0)) {
			$now = time();
			$elapsedTime = $now - $beginTime;
			echo "Updated $updatedSets in " . timeString($elapsedTime) . " (" . ($numRecords - $updatedSets) . " sets remaining)\n";
		}
		//loop through each record set
		foreach ($attributes as $attr) {
			//loop through each attribute
			$fieldType = (is_int($mappedTable['translated'])) ? PDO::PARAM_INT : PDO::PARAM_STR;
			$stmt->bindParam(":value_$attr", $mappedTable['translated'][$i][$attr], $fieldType);
			$stmt->bindParam(":cond_$attr", $mappedTable['original'][$i][$attr], $fieldType);
		}
		
		if ($stmt->execute()) {
			// everything ok
			$updatedSets++;
		}
		else {
			echo "\nThere was an error: " . print_r($stmt->errorInfo(), true) . "\n";
			echo "\nThe query was: $query";
			echo "\nOriginal: " . print_r($mappedTable['original'][$i]);
			echo "\nTranslated: " . print_r($mappedTable['translated'][$i]);
			$resp = readline('Continue even with this error? (y/N) : ');
			
			if (strtolower($resp) !== 'y' && strtolower($resp) !== 'yes') {
				return false;
			}
			else {
				"\nContinuing the update...\n";
			}
		}
	}
	
	$now = time();
	$elapsedTime = $now - $beginTime;
	
	echo "\n$updatedSets $tableName sets were updated in " . timeString($elapsedTime) . "\n";
	echo "\n\n---------------------------------------------------\n\n";
	return true;
	
}


function updateData(&$conn, $map) {
	
	echo "\n\n----------- Updating the data ------------ \n\n";
	
	foreach ($map as $tableName => $mappedTable) {
		if (!updateTable($conn, $tableName, $mappedTable)) {
			return false;
		}
	}
	
	return true;
}