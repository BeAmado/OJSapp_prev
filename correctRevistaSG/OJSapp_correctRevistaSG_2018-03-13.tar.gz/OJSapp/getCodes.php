<?php

require_once('helperFunctions.php');
require_once('cleanEncoding.php');

$conn = myConnect('localhost', 'root', 'root', 'revistasg3'); // from helperFunctions.php function #01



$stmt = $conn->prepare('SELECT setting_value FROM journal_settings WHERE locale="pt_BR" AND setting_name="additionalHomeContent"');

$myStmt = $conn->prepare('SELECT setting_value FROM journal_settings WHERE setting_name="minhaConf2"');

if (!$myStmt->execute()) exit("Did not execute the statement\n");

$arr = $myStmt->fetch(PDO::FETCH_ASSOC);
/*
if (!$stmt->execute()) exit("Did not execute the statement\n");

$arr = $stmt->fetch(PDO::FETCH_ASSOC);
*/
$str = nl2br($arr['setting_value']);

echo "\nMinha string vale:\n\n $str\n\n";

$strArray = explode('<br />', $str);

print_r($strArray);

$newStr = $strArray[12];

$codes = str2codes($newStr); //from cleanEncoding.php

echo "The string is : \n$newStr\n\n";

echo "The codes are: \n";
foreach ($codes as $code) {
	echo $code . " ";
}
echo "\n\n";