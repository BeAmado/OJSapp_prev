<?php

//functions to map some special chars that as it seems can't be translated to utf8 yet

// the ascci codes returened by the function ord()

//////////  ##############################  IN THE OJSapp FOR MIGRATION ###############################/////////////////////

/**codes:

32 = empty space

195,131, 194,129     = Á (&Aacute;)  dá bode
195,131, 226,128,154 = Â (&Acirc;)     OK
195,131, 194,141     = Í (&Iacute;)  dá bode
195,131, 197,160     = Ê (&Ecirc;)     OK
195,131, 198,146     = Ã (&Atilde;)    OK
*******, 194,170     = ê (&ecirc;)     OK
*******, 194,169     = é (&eacute;)    OK
*******, 194,167     = ç (&ccedil;)    OK
*******, 194,181     = õ (&otilde;)   OK
*******, 194,173     = í (&iacute;)    OK
*******, 194,161     = á (&aacute;)    OK
*******, 194,163     = ã (&atilde;)    OK
*******, 194,129     = À (&Agrave;)*   dá super bode
*******, 226,128,176 = É (&Eacute;)   OK
*******, 194,186     = ú (&uacute;)   OK
*******, 226,128,156 = Ó (&Oacute;) OK
*******, 226,128,161 = Ç (&Ccedil;) OK
*******, 226,128,157 = Ô (&Ocirc;) OK
*******, 226,128,162 = Õ (&Otilde;) OK
*******, 197,161     = Ú (&Uacute;) OK
*******, 
*******, 
*******, 
*******, 
*******, 
*******, 
*******, 

195,162,226,130,172, 197,147 = (left curly quotes, opening) OK
*******************, 194,157 = (right curly quotes, closing) dá bode
*******, 
*******, 
*******, 
*******, 

*/

//problem chars
$code2char = [
	"195,131,194,129" => ["Aacute", "Agrave"],
	"195,131,194,141" => "Iacute",
	"195,162,226,130,172,194,157" => "rdquo"
];




$char2code = [
	"acute" => [
		"A" => [194,129], // problem on translation
		"E" => [226,128,176],
		"I" => [194,141], //problem on translation
		"O" => [226,128,156],
		"U" => [197,161],
		"a" => [194,161],
		"e" => [194,169],
		"i" => [194,173],
		"o" => [],
		"u" => [194,186]
	],

	"circ" => [
		"A" => [226,128,154],
		"E" => [197,160],
		"I" => [],
		"O" => [226,128,157],
		"U" => [],
		"a" => [],
		"e" => [194,170],
	],

	"tilde" => [
		"A" => [198,146],
		"O" => [226,128,162],
		"a" => [194,163],
		"o" => [194,181]
	],

	"grave" => [
		"A" => [194,129], //problem on translation, same code as &Aacute;
		"E" => [],
		"I" => [],
		"O" => [],
		"U" => []
	],
	
	"cedil" => [
		"c" => [194,167],
		"C" => [226,128,161]
	]
];

//////////////// ################################################################################  //////////////////////////



$myEncodeChars = ["&" => "0123amper0123", ";" => "0123smcol0123"];
$myDecodeChars = ["0123amper0123" => "&", "0123smcol0123" => ";"];


function splitString($str) {
	$arr = [];
	
	$size = strlen($str);
	
	//echo "\nLength o $str = $size\n";
	for ($i = 0; $i < $size; $i++) {
		$char = substr($str, $i, 1);
		array_push($arr, $char);
	}
	
	return $arr;
}

function glueString($str_arr) {
	$str = "";
	foreach ($str_arr as $char) {
		$str .= $char;
	}
	return $str;
}

function translate2utf8($str) {
	$encoding = mb_detect_encoding($str);
	
	$in_encoding = $encoding;
	$out_encoding = $encoding;
	
	//echo "\nactual encoding is $encoding\n";
	
	/*if ($encoding === "UTF-8") {
		$out_encoding = "Windows-1252";
	}
	else {
		//$out_encoding = "UTF-8";
	}*/
	
	$in_encoding = "ISO-8859-1";
	$out_encoding = "UTF-8";
	
	return iconv($in_encoding, $out_encoding."//TRANSLIT", $str);
}

function search4Numbers($numbers, $arr, $offset = 0) {
	$sizeNumbers = count($numbers);
	$sizeArr = count($arr);
	//$found = false;
	$pos = -1;
	for($i = $offset; $i < ($sizeArr - $sizeNumbers); $i++) {
		$pos = $i;
		for($j = 0; $j < $sizeNumbers; $j++) {
			if ($arr[$i + $j] !== $numbers[$j]) {
				$pos = -1; // means the sequence is not yet found
				break; //breaking out of the inner loop with the $j control
			}
		}
		// if > -1 the sequence was found
		if ($pos > -1) break; //breaking out of the inner loop with the $i control
	}
	return $pos;
}

function str2codes($str) {
	$arr = splitString($str); // my function that returns an array with each letter of the string
	$codesArr = [];
	foreach ($arr as $char) {
		array_push($codesArr, ord($char));
	}
	return $codesArr;
}



function codes2char($codesArr) {
	$strArr = [];
	foreach ($codesArr as $code) {
		array_push($strArr, chr($code));
	}
	return $strArr;
}

function codes2str($codesArr) {
	return glueString(codes2char($codesArr));
}

function coerce2int($arr) {
	$returnArray = [];
	foreach ($arr as $item) {
		$num = (int) $item;
		array_push($returnArray, $num);
	}
	return $returnArray;
}


function transformCodes(&$codesArr) {
	
$problemCharCodes = [
	" Agrave " => [32,195,131,194,129,32], // same as Aacute with spaces surrounding (code 32 is an empty space)
	"Aacute" => [195,131,194,129],
	"Iacute" => [195,131,194,141],
	"rdquo" => [195,162,226,130,172,194,157]
];
	
$myChars = ["&" => "0123amper0123", ";" => "0123smcol0123"];
	$keys = array_keys($problemCharCodes);
	$i = 0;

	while ($i < count($keys)) {
		$search = $keys[$i];
		$pos = search4numbers($problemCharCodes[$search], $codesArr);
		if ($pos > -1) {
			//substitutes the codes
			array_splice($codesArr, $pos, count($problemCharCodes[$search]), str2codes($myChars["&"] . $search . $myChars[";"]));
		}
		else {
			$i++;
		}
	}

	return 0;
}

function transformCodesSG(&$strCodesArr) {
	$myCodes = array(
	////////////////// A ///////////////////////////////
	'Agrave' => array(195,128), 'Aacute' => array(195,129), 'Acirc' => array(195,130), 'Atilde' => array(195,131), 
	'agrave' => array(195,160), 'aacute' => array(195,161), 'acirc' => array(195,162), 'atilde' => array(195,163),
	
	//////////////////// E ////////////////////////////
	'Egrave' => array(195,136), 'Eacute' => array(195,137), 'Ecirc' => array(195,138), 
	'egrave' => array(195,168), 'eacute' => array(195,169), 'ecirc' => array(195,170), 
	
	////////////////// I ///////////////////////////////////
	'Igrave' => array(195,140), 'Iacute' => array(195,141), 'Icirc' => array(195,142), 'Iuml' => array(195,143),
	'igrave' => array(195,172), 'iacute' => array(195,173), 'icirc' => array(195,174), 'iuml' => array(195,175), 
	
	///////////////// O //////////////////////////////////////
	'Ograve' => array(195,146), 'Oacute' => array(195,147), 'Ocirc' => array(195,148), 'Otilde' => array(195,149),
	'ograve' => array(195,178), 'oacute' => array(195,179), 'ocirc' => array(195,180), 'otilde' => array(195,181),
	
	///////////////// U ////////////////////////////////////////
	'Ugrave' => array(195,153), 'Uacute' => array(195,154), 'Ucirc' => array(195,155), 'Uuml' => array(195,156), 
	'ugrave' => array(195,185), 'uacute' => array(195,186), 'ucirc' => array(195,187), 'uuml' => array(195,188), 
	
	//////////// Ç ///////////////////////////////////////////////
	'Ccedil' => array(195,135), 'ccedil' => array(195,167),
	
	'large_dash' => array(226,128,147)
	
	);
	
	
    //$myChars = ["&" => "0123amper0123", ";" => "0123smcol0123"];
	//$keys = array_keys($problemCharCodes);
	//$i = 0;
	
	$sizeStrCodes = count($strCodesArr);
	
	foreach ($myCodes as $specialChar => $spCharCodes) {
		$offset = 0;
		while ($offset < $sizeStrCodes) {
			$pos = search4numbers($spCharCodes, $strCodesArr, $offset); // search for the specialChar code in the array of codes strCodesArr from the string we want to translate
			if ($pos > -1) {
				//the sequence was found and the initial code position is stored in the variable $pos
				
				$substituteCodes = str2codes("&" . $specialChar . ";");
				
				if ($specialChar === 'large_dash') {
					$substituteCodes = array(45); // the large dash should be subst. by the normal dash - which has code 45
				}
	
				//substitutes the special codes with its html entity codes
				array_splice($strCodesArr, $pos, count($spCharCodes), $substituteCodes);
				/*
					array_splice usage:
				array array_splice ( array &$input , int $offset [, int $length = count($input) [, mixed $replacement = array() ]] )
				*/
				
				// increment the offset value with the length of the substituteCodes
				$offset += count($substituteCodes);
			}
			else {
				$offset = $sizeStrCodes; // breaks out of the while offset < sizeStrCodes
			}
		}// end of the while offset < sizeStrCodes
		
	}// end of the foreach myCodes

	return 0;
}

function myTranslateSG($str) {
	$codes = str2codes($str);
	transformCodesSG($codes);
	return codes2str($codes);
}


function myEncodeSpecialChars($str) {
	$codes = str2codes($str); //step 1
	transformCodes($codes); //step 2
	return codes2str($codes); //step 3
}

function myDecodeSpecialChars($str) {
	$str = htmlentities($str); //step 5
	
$myChars = ["&" => "0123amper0123", ";" => "0123smcol0123"];
	$str = str_replace($myChars["&"], "&", $str); //step 6
	$str = str_replace($myChars[";"], ";", $str); //step 6

	return html_entity_decode($str); //step 7
}

function unmessEncoding($str) {
	$str = myEncodeSpecialChars($str); // steps 1 through 3
	$str = translate2utf8($str); // step 4
	$str = myDecodeSpecialChars($str); // steps 5 through 7
	return $str;
}
